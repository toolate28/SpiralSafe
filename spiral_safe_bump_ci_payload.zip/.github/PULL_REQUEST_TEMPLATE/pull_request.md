---
name: Pull request template
about: Use this template for PRs that add CI, bump templates, or agent-facing files
title: ''
labels: ''
assignees: ''

---

## Summary

Describe the change in 1-2 sentences.

## Why

Why this change is needed and what it enables.

## What changed

- Files added
- Scripts
- CI workflows

## Verification / Testing

- [ ] `scripts/validate-bump.sh` passes locally
- [ ] `scripts/validate-branch-name.sh` tested on example branches
- [ ] `bash scripts/verify-environment.sh` prints `ENV OK`

## Notes

- Sensitive logs must be redacted before sharing
- Any change that allows production writes must be reviewed by a human
