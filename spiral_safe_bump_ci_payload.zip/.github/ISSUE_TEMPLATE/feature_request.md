---
name: Feature request
about: Suggest an improvement or new capability; the request should include an ATOM-style intent if possible
title: ''
labels: enhancement
assignees: ''
---

**Summary**
Short description of the desired feature.

**Motivation**
Why is this feature useful?

**Implementation ideas**
High-level notes on how this could be implemented (optional).

**Acceptance criteria**
- [ ] Small, testable goals for completion
- [ ] Verification commands/examples

**ATOM / Intent**
If you have an ATOM tag or intended intent line, include here:
`ATOM-<TYPE>-<YYYYMMDD>-NNN: <short intent>`
