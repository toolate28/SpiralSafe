---
name: Bug report
about: Report a problem, include reproduction steps and ATOM tags if available
title: ''
labels: bug
assignees: ''
---

**Summary**
A clear and concise description of the bug.

**Steps to reproduce**
1.
2.
3.

**Expected behavior**
What you expected to happen.

**Actual behavior**
What actually happened.

**Environment**
- Repository:
- Branch:
- ATOM tag (if any):

**Logs / outputs**
Paste relevant log snippets or link to `.claude/logs/*`. Redact secrets.

**Additional context**
Add any other context about the problem here.
